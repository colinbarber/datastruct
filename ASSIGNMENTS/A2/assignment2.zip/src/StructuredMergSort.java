public class StructuredMergSort {

    public static void sort(int[] arr) {

        int[] buff = arr;
        JumpList runs;



    }
}
