public class ARun {

    private int start;
    private int length;

    public ARun () { start = 0; length = 0; }
    public ARun (int s, int l) { start = s; length = l; }

    public int getStart() { return start; }
    public int getLength() { return length; }
}
